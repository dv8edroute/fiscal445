import fiscal445 as fc5

import sys
print('Use: python -m fiscal445 --help for more')
if len(sys.argv)==2 and sys.argv[1]=='--help':
    help(fc5)
    help(fc5.Calendar)
    help(fc5.Date_functions)
